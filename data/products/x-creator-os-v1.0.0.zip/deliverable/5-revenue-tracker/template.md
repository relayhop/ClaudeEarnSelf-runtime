# Revenue Tracker

> Notion template — aggregate income across Gumroad / Substack / Patreon / Ko-fi / sponsorships / affiliate / freelance — see actual MRR + breakdown.
> **Import**: New page → ⋯ → Import → Markdown → select this file.

---

## Database 1: Income Events

| Property | Type | Options / Formula |
|---|---|---|
| Description | Title | (e.g. "Gumroad sale: X Creator OS") |
| Date | Date | (when payment received) |
| Amount | Number | (gross USD) |
| Platform fee | Number | (manual: e.g. Gumroad 10% + Stripe 2.9% + $0.30) |
| Net | Formula | `prop("Amount") - prop("Platform fee")` |
| Currency | Select | USD / EUR / GBP / TWD / Other |
| Source | Select | Gumroad / Substack / Patreon / Ko-fi / Buymeacoffee / Sponsorship / Affiliate / Freelance / Consulting / Course / Royalty / Tip / Other |
| Source detail | Text | (e.g. "X Creator OS Standard"; "Beehiiv sponsorship issue 12") |
| Type | Select | One-time / Recurring (monthly) / Recurring (annual) / Refund / Chargeback |
| Customer email | Email | (optional, for cohort analysis) |
| Country | Select | (top 10 + Other) |
| Recurring? | Checkbox | TRUE if MRR-contributing |
| MRR contribution | Formula | `if(prop("Recurring?"), prop("Net"), 0)` |
| Recurring cycle months | Number | (1 / 12 / etc.) |
| Notes | Text | |

---

## Database 2: Monthly Summary

| Property | Type | Options / Formula |
|---|---|---|
| Month | Date | (1st of month) |
| Total gross | Rollup → Income Events | sum Amount |
| Total net | Rollup → Income Events | sum Net |
| New MRR added | Rollup | sum MRR contribution where Type = Recurring AND Date in month |
| Refunds / chargebacks | Rollup | sum Net where Type IN [Refund, Chargeback] |
| Net after refunds | Formula | Total net - abs(Refunds) |
| # transactions | Rollup → Income Events | count where Date in month |
| Avg transaction value | Formula | Total gross / # transactions |
| Top source | (manual or rollup) | which source contributed most |

---

## Views — Income Events

### 1. 💰 This month
- Filter: Date within current month
- Sort: Date desc
- Layout: Table
- Use: real-time tracking

### 2. 📅 Last 90 days
- Filter: Date >= TODAY-90
- Group by: Source
- Layout: Board
- Use: source breakdown, see what's growing

### 3. 🔁 Recurring revenue (MRR detail)
- Filter: Recurring? = TRUE AND Type != Refund
- Sort: Net desc
- Use: see your MRR base by customer

### 4. ❌ Refunds + chargebacks
- Filter: Type IN [Refund, Chargeback]
- Sort: Date desc
- Use: track problem customers / patterns

### 5. 🌍 By country (cohort analysis)
- Group by: Country
- Sum: Net
- Use: where do buyers actually come from

### 6. 🏆 Top transactions (lifetime)
- Sort: Net desc
- Top 20
- Use: see biggest deals — which sources, what cycles

---

## Views — Monthly Summary

### 7. 📊 Last 12 months
- Sort: Month desc
- Layout: Table with all rollup columns
- Use: trend visualization

### 8. 🚨 Down months (vs prev)
- Filter: Total net < previous month's Total net
- Use: spot trend reversal early

---

## Workflow

### Per income event (1 min when payment lands)
1. New row in Income Events
2. Fill: Description / Date / Amount / Platform fee / Source / Type
3. If recurring: check Recurring + set cycle months

### Weekly (5 min, Sunday)
1. Open **💰 This month** → quick scan, anything missing?
2. Cross-check Gumroad / Substack / Patreon dashboards vs your log

### Monthly (15 min, 1st of next month)
1. Add row to Monthly Summary database (or wait for rollups to compute)
2. Open **📅 Last 90 days** — what trended up / down
3. Open **🔁 Recurring revenue** — any churn? Any new MRR?
4. Tag 3 actions for next month based on data

### Quarterly (30 min)
1. Open **📊 Last 12 months**
2. Plot trend (export to spreadsheet for chart if Notion native chart insufficient)
3. Strategy adjustment: which source has best ROI on your time?

---

## Pre-loaded sample data

| Description | Date | Amount | Platform fee | Net | Source | Type |
|---|---|---|---|---|---|---|
| Gumroad: Tweet Idea Vault (free) | 2026-05-08 | 0 | 0 | 0 | Gumroad | One-time |
| Gumroad: X Creator OS Standard | 2026-05-08 | 14.50 | 2.05 | 12.45 | Gumroad | One-time |
| Beehiiv sponsorship issue 12 | 2026-04-15 | 1500 | 0 | 1500 | Sponsorship | One-time |
| Substack monthly subscription | 2026-04-30 | 87 | 8.70 | 78.30 | Substack | Recurring (monthly) |
| Patreon monthly | 2026-04-30 | 45 | 4.50 | 40.50 | Patreon | Recurring (monthly) |
| Refund: Gumroad early bug | 2026-03-12 | -14.50 | 0 | -14.50 | Gumroad | Refund |

---

## Tips

- **Net is what matters**: gross is vanity, net is reality. Always log fee.
- **MRR is the gold metric for indie creators**: focus on growing it, not just one-time spikes
- **Refunds <5% is healthy**; >10% = product issue
- **Top customer email column**: log it (anonymized if needed) — repeat buyers fund the business
- **Track Source detail granularly**: not just "Sponsorship" but "Beehiiv sponsorship issue 12" — this lets you analyze ROI per platform / sponsor

---

*Part of The X Creator OS — Notion Stack.*
