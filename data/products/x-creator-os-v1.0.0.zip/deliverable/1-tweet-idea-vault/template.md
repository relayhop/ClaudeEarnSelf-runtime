# Tweet Idea Vault

> Notion template — captures, queues, schedules, and recycles your tweet ideas.
> **Import this file into Notion**: New page → ⋯ menu → Import → Markdown → select this file.

---

## Database: Tweet Ideas

| Property | Type | Options / Formula |
|---|---|---|
| Idea | Title | (text) |
| Status | Select | 💡 Raw / ✏️ Drafting / ⏳ Queued / 🚀 Posted / ♻️ Recycled |
| Format | Select | Single tweet / Thread / Reply guy / Quote tweet / Image post |
| Hook strength | Select | 🔥 banger / 👌 solid / 🤷 maybe / 🧊 cold |
| Topic | Multi-select | building in public / lessons / observations / hot takes / personal / tools / wins / fails |
| Body | Text | Full tweet / thread content |
| Hook (first 280) | Text | Just the first tweet — the scroll-stopper |
| Scheduled date | Date | (when you plan to post) |
| Posted date | Date | (when actually went live) |
| Performance | Select | Banger / Decent / Flop / Not yet measured |
| Likes | Number | (manual entry after 24h) |
| Replies | Number | (manual entry) |
| Reposts | Number | (manual entry) |
| Impressions | Number | (manual entry) |
| Engagement rate | Formula | `prop("Likes") + prop("Replies")*2 + prop("Reposts")*3 / prop("Impressions") * 100` (weighted) |
| Source link | URL | (where you got the idea — article / podcast / convo) |
| Recycle eligible | Checkbox | Mark TRUE for evergreen ideas to repost in 30+ days |
| Last recycled | Date | (auto-updated when you re-queue) |
| Notes | Text | (extra context, follow-up tweets, etc.) |

---

## Views

### 1. 💡 Inbox (raw capture)
- **Filter**: Status = 💡 Raw
- **Sort**: Created descending
- **Layout**: Gallery (Hook visible)
- **Use**: every time you have an idea, dump it here in <10 seconds

### 2. ✏️ Drafting now
- **Filter**: Status = ✏️ Drafting
- **Sort**: Created ascending
- **Layout**: List
- **Use**: this week's writing focus

### 3. ⏳ Queue (ready to post)
- **Filter**: Status = ⏳ Queued AND Scheduled date is set
- **Sort**: Scheduled date ascending
- **Layout**: Calendar (by Scheduled date)
- **Use**: see your next 14 days of content

### 4. 🚀 Posted (last 30 days)
- **Filter**: Status = 🚀 Posted AND Posted date within last 30 days
- **Sort**: Posted date descending
- **Layout**: Table with Likes / Replies / Engagement rate
- **Use**: weekly review — what worked

### 5. 🏆 Bangers (recycle pool)
- **Filter**: Performance = Banger AND Recycle eligible = ✓ AND Last recycled before 30 days ago
- **Sort**: Engagement rate descending
- **Layout**: Gallery
- **Use**: monthly — pick top 3 to recycle

### 6. 🧊 Graveyard
- **Filter**: Performance = Flop OR Hook strength = 🧊 cold
- **Layout**: Table
- **Use**: pattern recognition — what consistently flops? Stop writing it.

---

## Workflow (use it like this)

### Daily (5 min)
1. Open **💡 Inbox** view
2. Dump all raw ideas from the day (phone notes, screenshots, convos)
3. Quick-sort: anything obviously hot → set Hook strength → move to ✏️ Drafting

### Weekly (20 min)
1. Open **✏️ Drafting** view
2. Finish 5-7 tweets/threads
3. Set Status = ⏳ Queued + Scheduled date
4. They appear in **⏳ Queue** calendar

### Post-publish (1 min per tweet)
1. After 24h, fill in Likes / Replies / Reposts / Impressions
2. Engagement rate auto-computes
3. Set Performance = Banger / Decent / Flop

### Monthly (30 min review)
1. Open **🚀 Posted (last 30 days)**
2. Sort by Engagement rate
3. Pattern-spot what worked
4. Open **🏆 Bangers** → recycle top 3 with new framing
5. Open **🧊 Graveyard** → identify topics to stop wasting time on

---

## Pre-loaded sample data

| Idea | Status | Format | Hook | Topic |
|---|---|---|---|---|
| "Built X in 2 weeks. 3 lessons:" | ⏳ Queued | Thread | 🔥 banger | building in public, lessons |
| "Hot take: Notion is overrated for solopreneurs." | 💡 Raw | Single | 🤷 maybe | hot takes |
| "What I'd do differently if I started over" | ✏️ Drafting | Thread | 👌 solid | lessons, personal |

(Delete these once you're set up. They're just to show what filled rows look like.)

---

## Tips

- **Don't over-categorize**: Topic is multi-select for a reason. Most tweets have 2-3 topics. Don't agonize.
- **Hook strength is for YOU**: it's a reminder — write more 🔥 bangers, less 🧊 cold takes.
- **Recycle ruthlessly**: a banger from 90 days ago is new content for 80% of your followers (algorithm shows tweets to ~5-10% of followers).
- **Performance = Flop is fine**: track it, learn from it, move on.

---

## Why this template exists

Most tweet trackers are either:
- Too simple (single text field — useless for thread building)
- Too bloated (47 properties, content-pillar matrix — abandoned in 2 weeks)

This is the middle path. **Capture fast (Inbox), publish on schedule (Queue), learn from data (Posted analytics), recycle the wins (Bangers)**.

That's it. Use it for 30 days, see the difference.

---

*Part of The X Creator OS — Notion Stack. Standard ($14.50) includes all 5 templates + 5 themes + setup guide + lifetime updates.*
