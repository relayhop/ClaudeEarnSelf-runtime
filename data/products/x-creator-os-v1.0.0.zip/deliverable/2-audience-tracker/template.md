# Audience Growth Tracker

> Notion template — daily logs of follower / engagement / impression metrics across platforms.
> **Import**: New page → ⋯ → Import → Markdown → select this file.

---

## Database 1: Daily Snapshot

| Property | Type | Options / Formula |
|---|---|---|
| Date | Date | (one row per day, manually log) |
| Platform | Select | X (Twitter) / Substack / YouTube / LinkedIn / Threads / Bluesky |
| Followers | Number | (current count, manual) |
| Δ Followers | Formula | `prop("Followers") - prop("Prev Followers")` (rollup from yesterday) |
| Posts today | Number | (manual) |
| Total impressions today | Number | (manual or from analytics) |
| Total engagements today | Number | (likes + replies + reposts) |
| Engagement rate | Formula | `prop("Total engagements today") / prop("Total impressions today") * 100` |
| Best post | Relation → Tweet Idea Vault | (link to top performing tweet of the day) |
| Notes | Text | (anything notable — viral tweet, algorithm change feel, etc.) |

---

## Database 2: Weekly Rollup

| Property | Type | Options / Formula |
|---|---|---|
| Week start | Date | (Monday of the week) |
| Platform | Select | X / Substack / YouTube / LinkedIn / Threads / Bluesky |
| Followers EOW | Number | (Sunday count) |
| Δ Followers WoW | Number | (this week - last week) |
| Total posts | Rollup → Daily Snapshot count | sum where Date in week |
| Total impressions | Rollup → Daily Snapshot | sum |
| Total engagements | Rollup → Daily Snapshot | sum |
| Avg engagement rate | Formula | engagements / impressions × 100 |
| Best day | Rollup → Daily Snapshot | max Followers |
| Worst day | Rollup → Daily Snapshot | min Followers |

---

## Views

### 1. 📅 Today (single day input)
- Database: Daily Snapshot
- Filter: Date = TODAY
- Layout: Form view (1 row per platform)
- Use: 5 min daily log

### 2. 📈 Last 30 days (line chart)
- Database: Daily Snapshot
- Filter: Date >= TODAY-30
- Layout: Calendar OR table sortable by Date desc
- Use: trend visualization

### 3. 🏆 Weekly leaderboard
- Database: Weekly Rollup
- Filter: Week start within last 12 weeks
- Sort: Δ Followers WoW desc
- Layout: Table
- Use: which week did your best growth happen → reverse engineer what you did

### 4. 🚨 Stagnation alert
- Database: Weekly Rollup
- Filter: Δ Followers WoW <= 0 AND Week start within last 4 weeks
- Layout: Table
- Use: see if you're plateauing

### 5. 🎯 Per-platform compare
- Database: Daily Snapshot
- Group by: Platform
- Sort: Date desc
- Layout: Board
- Use: which platform is growing fastest right now

---

## Workflow

### Daily (5 min, evening)
1. Open **📅 Today** view
2. For each platform you posted on, log: followers / posts / impressions / engagements
3. Optional: link Best post (from Tweet Idea Vault)

### Weekly (10 min, Sunday evening)
1. Open Weekly Rollup database
2. Add a row for each platform with this week's data
3. Δ Followers WoW computes automatically
4. Open **🏆 Weekly leaderboard** — see how this week ranks

### Monthly (15 min)
1. Open **📈 Last 30 days**
2. Compare to previous 30 days (manual)
3. Spot the inflection points — what changed those weeks?
4. Update strategy in your Tweet Idea Vault (more of the format that worked)

---

## Pre-loaded sample data

| Date | Platform | Followers | Posts | Impressions | Engagements |
|---|---|---|---|---|---|
| 2026-05-09 | X | 1,247 | 3 | 12,450 | 178 |
| 2026-05-09 | Substack | 312 | 1 | 1,200 | 45 |
| 2026-05-09 | LinkedIn | 890 | 1 | 3,400 | 28 |

---

## Why this template exists

You can't grow what you don't measure. But typical "social analytics" tools:
- Cost $50-200/mo (Buffer, Hootsuite, Later)
- Show you metrics but not patterns
- Don't link to *which content* drove growth

This template:
- Free (just Notion + 5 min/day of yours)
- Cross-platform (no tool covers all 6 platforms equally)
- **Linked to your content** (via Best post relation → see exactly what worked)

---

*Part of The X Creator OS — Notion Stack.*
