# The X Creator OS — Setup Guide

Welcome 🎉 You just got the **X Creator OS — Notion Stack**.

This is the README. Spend 10 minutes here, then you're set up forever.

---

## What's in this folder

```
deliverable/
├── README.md                    ← you are here
├── 1-tweet-idea-vault/         ← Template 1
│   ├── template.md             ← Notion-importable
│   └── template.csv            ← spreadsheet fallback
├── 2-audience-tracker/
├── 3-newsletter-pipeline/
├── 4-sponsorship-crm/
├── 5-revenue-tracker/
├── 6-stack-dashboard/          ← Pro Pack only
└── themes/                     ← 5 visual themes
```

---

## Setup in Notion (recommended, 10 min)

### Step 1 — Create a new Notion workspace section
In your Notion sidebar, hit **+ New page** and call it **"X Creator OS"**.

### Step 2 — Import each template
For each of the 5 templates (folders 1 through 5):

1. Click the **⋯ menu** (top right of the new page)
2. Select **Import**
3. Choose **Markdown & CSV**
4. Select `template.md` from the folder
5. Hit **Import**

Notion will create a new sub-page with the template structure pre-built (databases / properties / views all set up).

Repeat for all 5 templates. Total: ~5 minutes.

### Step 3 — Pick a theme (optional)
Open `themes/` folder. Choose one:
- ☁️ Minimalist
- 🌑 Dark Mode
- 🌸 Pastel
- 💾 Y2K
- ⬛ Brutalist

Each theme has a `theme.md` with: page cover URL, emoji set, color palette, font pairing. Apply to your X Creator OS top-level page.

### Step 4 — Pin to your sidebar
Right-click the X Creator OS page → **Add to favorites**. Now it's 1 click away forever.

### Step 5 — Quick test
Open **Tweet Idea Vault** sub-page. Add 1 row. Verify properties / views work. ✓

You're done. Total time: ~10 minutes.

---

## Setup in Google Sheets (alternative, 5 min)

If you prefer Sheets over Notion:

1. Create a new Google Sheet
2. For each template, **File → Import → Upload** the `template.csv`
3. Each template becomes a tab

Sheets won't have:
- Linked databases between templates (Stack Dashboard requires Notion)
- Calendar views (Notion-specific)
- Rollup formulas (Sheets formulas have to be manually written)

But for solo use: Sheets works fine for 1-2 templates.

---

## Setup in any other tool (3 min)

The `template.md` files are plain Markdown — they import to:
- ✅ Notion (best)
- ✅ Obsidian (good for personal use)
- ✅ Logseq
- ✅ Roam
- ✅ Anytype
- ✅ Anytype, Capacities, etc.

The `template.csv` files import to:
- ✅ Google Sheets
- ✅ Excel
- ✅ Airtable (paste-import; lose some property types)
- ✅ Coda

Pick what you already use.

---

## Daily / weekly / monthly workflow

Each template has its own workflow section in its `template.md`. **The 30-second version**:

| Cadence | Template | Time |
|---|---|---|
| Daily | Tweet Idea Vault — Inbox capture | 5 min |
| Daily | Audience Tracker — log day | 5 min |
| Per-issue (weekly) | Newsletter Pipeline | 3-5 hr per issue |
| Weekly | Sponsorship CRM — followup pass | 30 min |
| Per-event | Revenue Tracker — log income | 1 min each |
| Weekly | All — review pass | 20 min total |
| Monthly | All — strategic review | 60 min total |

**Total commitment: 30-60 min/day, scaling to 4 hr/month strategic.**

---

## What's in **Pro Pack ($29 upgrade)**:

- **Stack Dashboard** (folder `6-stack-dashboard/`) — cross-template aggregation:
  - Today: top tweet + new MRR + open sponsor leads
  - Weekly: content velocity vs revenue change
  - Monthly: which platform / which sponsor / which content drives most ARPU
- **Sponsorship Pitch Deck** templates (V1/V2/V3 pre-written outreach)
- **Brand Voice Worksheet** (define your voice in 8 dimensions)

If you bought Standard, you'll see the `6-stack-dashboard/` folder is empty (placeholder). Upgrade to Pro Pack via Gumroad to unlock.

---

## What's in **Annual Vault ($59 upgrade)**:

- Everything in Pro Pack
- **Quarterly content audit checklist** (4 page PDF)
- **Year-end review template** (Notion)
- **12-month auto-update guarantee** — every quarter, new templates / improvements auto-delivered to your Gumroad library

---

## Lifetime Updates Promise

**Your purchase includes lifetime updates.** Whenever a new version drops:
1. Gumroad library auto-updates the file
2. You get an email notification
3. Re-import the updated `template.md` (or just glance at `version.json` to see what changed)

Current version: **1.0.0** (released 2026-05-09)
Planned next: **1.1.0 ~2026-08** (X analytics integration), **2.0.0 ~2026-12** (Stack Dashboard 2.0)

See `version.json` (in product folder) for full changelog.

---

## Help / questions

This is a 100% digital product. We don't offer 1:1 setup help (that's why setup is designed to take 10 minutes).

Common issues:
- **"Notion import button doesn't work"** → Try a fresh page; if still broken, your Notion account may have file-size limits (free tier OK, but 50KB+ files sometimes fail). Workaround: copy-paste the markdown manually into a new page.
- **"CSV import lost some columns"** → Some Notion property types (Relation, Rollup, Formula) don't transfer via CSV. Use the `.md` import instead.
- **"I want to customize a database property"** → Yes, please! These are starting points, not commandments. Add columns / change selects / make it yours.

Bug report or feature request: file a GitHub issue at [`relayhop/x-creator-os-issues`](https://github.com/relayhop) (will be created in v1.1).

---

## Refund policy

No refunds (instant access). But Lifetime Updates means anything broken gets fixed in next version.

---

## License

Personal use license. You can use these templates for your own creator business and make money from your audience using them.

You **cannot**:
- Resell / redistribute the templates as your own product
- Include them in another bundle for sale
- Use the brand "X Creator OS" for your own product

You **can**:
- Modify freely for personal use
- Share screenshots of how you use it
- Recommend the original product (use your affiliate link 😉 — see Gumroad library after purchase)

---

## Version

v1.0.0 — released 2026-05-09
© 2026 — All templates and materials

---

**Ready? Start with Step 1 above. 10 minutes to set up. Then you're done forever. 🚀**
