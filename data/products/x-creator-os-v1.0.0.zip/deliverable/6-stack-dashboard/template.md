# Stack Dashboard (Pro Pack +)

> Cross-template aggregation hub. Single page that shows you everything across the 5 templates: today's top tweet, new MRR, open sponsor leads, this week's content velocity, etc.
>
> **Requires** the 5 base templates (Tweet Idea Vault / Audience Tracker / Newsletter Pipeline / Sponsorship CRM / Revenue Tracker) to be set up first as Notion databases. Once they're imported, this dashboard creates linked-database views referencing them.
>
> **Pro Pack ($29) and Annual Vault ($59) buyers only.**
> If you bought Standard ($14.50): upgrade via Gumroad to unlock this folder.

---

## Top section: 🌅 Today

A linked-database snapshot section showing:

| Block | Source DB | View config |
|---|---|---|
| **Top tweet today** | Tweet Idea Vault | filter: Status = 🚀 Posted AND Posted date = TODAY, sort: Engagement rate desc, limit 1 |
| **Followers Δ today** | Audience Tracker | filter: Date = TODAY, group by Platform, show Δ Followers |
| **Open sponsor leads needing followup** | Sponsorship CRM | filter: Stage IN [💬 Replied, 🤝 Negotiating], sort: Last interaction asc, limit 5 |
| **Today's revenue events** | Revenue Tracker | filter: Date = TODAY, sort: Net desc |
| **Newsletter draft status** | Newsletter Pipeline | filter: Status IN [✏️ Drafting, 👀 Editing], limit 1 |

---

## Middle section: 📅 This Week

| Block | Source DB | View config |
|---|---|---|
| **Content velocity** | Tweet Idea Vault | filter: Posted date within current week, count + group by Format |
| **Audience growth WoW** | Audience Tracker (Weekly Rollup) | filter: Week start = current Monday, group by Platform |
| **Newsletter sent this week?** | Newsletter Pipeline | filter: Send date within current week |
| **Sponsorship pipeline value** | Sponsorship CRM | filter: Stage IN [🤝 Negotiating, ✅ Signed], sum Final price |
| **Weekly revenue** | Revenue Tracker | filter: Date within current week, sum Net |

---

## Bottom section: 📊 Monthly Aggregation

A linked rollup database that joins all 5 templates by month:

| Property | Type | Source |
|---|---|---|
| Month | Date | (1st of month) |
| Tweets posted | Rollup | count Tweet Idea Vault Status=🚀 Posted in month |
| Tweet impressions total | Rollup | sum Impressions in month |
| Tweet engagement total | Rollup | sum (Likes + Replies + Reposts) |
| New followers gained | Rollup | sum Δ Followers from Audience Tracker monthly |
| Newsletters sent | Rollup | count Newsletter Pipeline Status=📬 Sent in month |
| Avg open rate | Rollup | avg Open rate % |
| Sponsorships closed | Rollup | count Sponsorship CRM Stage=📦 Delivered in month |
| Sponsorship revenue | Rollup | sum Sponsorship CRM Final price where delivered in month |
| Total revenue | Rollup | sum Revenue Tracker Net in month |
| Total MRR added | Rollup | sum Revenue Tracker MRR contribution in month |
| **Hours invested** | Number (manual) | (you log: estimated content+admin time) |
| **$/hour** | Formula | Total revenue / Hours invested |
| **Δ growth multiplier** | Formula | This month's tweet impressions / last month's |

---

## Linked-database setup instructions

After importing each of the 5 base templates as Notion sub-pages, do this:

1. Open this Stack Dashboard page
2. For each "Block" listed above, type `/linked` and select **Linked database**
3. Pick the corresponding source database from your X Creator OS workspace
4. Apply the filter / sort / view config as documented
5. Save view name with the block label (e.g. "Top tweet today")

Total setup time: ~15-20 min for all blocks.

---

## What this gives you that the 5 templates alone don't

**Insight:**
- "I posted 47 tweets, gained 312 followers, sent 4 newsletters, closed 1 sponsor — was that worth it?"
- "My $/hour is dropping — I'm shipping more but not making more — what changed?"
- "Sponsorship pipeline value is $4,200 — when does that close?"

**You can't see this from any one template alone.** Stack Dashboard is the integration layer.

---

## Pre-loaded sample dashboard view

```
┌─────────────────────────────────────────────────────────┐
│  🌅 Today (2026-05-09)                                  │
├─────────────────────────────────────────────────────────┤
│  Top tweet:    "How I systematized X content in 30 days │
│                 → 1,847 impressions, 12.3% engagement"  │
│                                                          │
│  Followers Δ:  X +12  Substack +3  LinkedIn +1          │
│                                                          │
│  Sponsor leads needing followup:                        │
│   • Beehiiv — replied 2026-05-07, no response in 2 days│
│   • Notion — cold pitched 2026-04-20, 19 days silent    │
│                                                          │
│  Today's revenue: $12.45 net (Gumroad: X Creator OS)    │
│                                                          │
│  Newsletter draft: Issue #14 (Q&A: my Notion stack)     │
│                    — Status: ✏️ Drafting                 │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📅 This Week (May 5-11)                                 │
├─────────────────────────────────────────────────────────┤
│  Content: 14 tweets / 1 thread / 0 newsletters          │
│  Followers WoW: X +47  Substack +8  LinkedIn +3         │
│  Sponsorship pipeline: $1,500 (Beehiiv) negotiating     │
│  Revenue this week: $112.45                             │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│  📊 May 2026 (in progress)                               │
├─────────────────────────────────────────────────────────┤
│  Tweets:  14 / 60 (target)                               │
│  Newsletters: 1 / 4 (target)                             │
│  Sponsorships closed: 0 (1 in pipeline)                  │
│  Revenue: $112.45 (vs $387 in April)                     │
│  $/hour: $4.50 (target $20+)                             │
│  Growth multiplier: 0.8x (down month — review)           │
└─────────────────────────────────────────────────────────┘
```

---

## Why Stack Dashboard is Pro Pack only

The 5 base templates each solve ONE thing well. The Stack Dashboard solves the **integration problem** — and integration is where most "all-in-one" tools fail (too coupled, too rigid).

Because Stack Dashboard takes 15-20 min to set up properly (linked databases, rollups, formulas), it's bundled separately. Standard buyers get the templates; Pro buyers get the templates + the connective tissue.

---

*Part of The X Creator OS — Notion Stack. Pro Pack ($29) and Annual Vault ($59) only.*
