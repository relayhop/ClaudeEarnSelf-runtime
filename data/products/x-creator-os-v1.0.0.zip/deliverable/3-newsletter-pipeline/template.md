# Newsletter Pipeline

> Notion template — drafts → scheduled → sent → open-rate analytics for your newsletter (Substack / Beehiiv / Convertkit / ghost / mailchimp / etc.)
> **Import**: New page → ⋯ → Import → Markdown → select this file.

---

## Database: Newsletter Issues

| Property | Type | Options / Formula |
|---|---|---|
| Title | Title | (subject line) |
| Status | Select | 💭 Concept / ✏️ Drafting / 👀 Editing / ⏳ Scheduled / 📬 Sent / 🗄️ Archived |
| Issue # | Number | (sequential, manual) |
| Issue type | Select | Feature essay / Linkroll / Tutorial / Behind-the-scenes / Q&A / Ad-supported / Sponsored |
| Word count | Number | (rough, manual) |
| Subject line | Text | (final email subject) |
| Subject line score | Select | 🔥 strong / 👌 OK / 🤷 weak |
| Hook (first 100 words) | Text | (the open-then-or-not paragraph) |
| Body | Text | (the article) |
| CTA | Text | (what action you ask reader to take) |
| Send date | Date | (scheduled or actual) |
| Recipients | Number | (subscriber count at send time) |
| Open rate % | Number | (filled in 48h after send) |
| Click rate % | Number | (filled in 48h after send) |
| Unsubscribes | Number | (filled in 48h after send) |
| New subs gained | Number | (in 7 days post-send, e.g. via referral) |
| Performance | Formula | `if(prop("Open rate %") >= 50, "🏆 Top", if(prop("Open rate %") >= 30, "👌 Decent", "🧊 Flop"))` |
| Tweet teasers | Relation → Tweet Idea Vault | (which tweets promoted this issue) |
| Notes | Text | (post-mortem reflections) |

---

## Views

### 1. ✏️ This week's draft
- Filter: Status IN [💭 Concept, ✏️ Drafting, 👀 Editing]
- Sort: Send date asc
- Layout: List
- Use: writing focus

### 2. ⏳ Scheduled (next 4 weeks)
- Filter: Status = ⏳ Scheduled
- Sort: Send date asc
- Layout: Calendar
- Use: see your editorial calendar

### 3. 📬 Sent (last 90 days)
- Filter: Status = 📬 Sent AND Send date >= TODAY-90
- Sort: Send date desc
- Layout: Table with Open rate / Click rate / New subs columns
- Use: weekly review

### 4. 🏆 Top performers
- Filter: Performance = 🏆 Top
- Sort: Open rate desc
- Layout: Gallery
- Use: see what subjects / formats actually open

### 5. 🧊 Underperformers
- Filter: Performance = 🧊 Flop
- Sort: Send date desc
- Layout: Table
- Use: pattern-recognize what dies

### 6. 📈 Subject-line A/B history
- Filter: Issue type = Feature essay
- Group by: Subject line score
- Sort: Open rate desc
- Use: build a sense of what subject patterns convert

---

## Workflow

### Per-issue (≈3-5 hour total spread over 1-2 weeks)
1. **Concept** (10 min): create row, status 💭 Concept, draft Title + Issue type
2. **Drafting** (1-3 hour): status ✏️ Drafting, fill Body
3. **Editing** (30 min): status 👀 Editing, polish Hook + CTA
4. **Schedule** (10 min): status ⏳ Scheduled, set Send date, copy to Substack/Beehiiv/etc.
5. **Send day** (auto): status 📬 Sent, fill Recipients
6. **+48h post-send** (5 min): fill Open rate / Click rate / Unsubscribes
7. **+7d post-send** (5 min): fill New subs gained, write Notes

### Weekly (10 min)
- Open **🏆 Top performers** + **🧊 Underperformers**
- Note pattern in Notes field of next planned issue

### Monthly (15 min)
- Open **📈 Subject-line A/B history**
- See which subject phrasings consistently win
- Update next month's planned subjects

---

## Pre-loaded sample data

| Title | Status | Issue # | Type | Subject line | Open rate | Performance |
|---|---|---|---|---|---|---|
| "How I systematized my X content in 30 days" | 📬 Sent | 12 | Feature essay | "I tried to be a daily X poster. Here's what I learned." | 47.3 | 👌 Decent |
| "The 3 newsletters that taught me copywriting" | ⏳ Scheduled | 13 | Linkroll | "These 3 newsletters changed how I write." | — | — |
| "Q&A: my Notion stack" | ✏️ Drafting | 14 | Q&A | (TBD) | — | — |

---

## Tips

- **Subject line is 80% of the work**: write 5 subject options per issue, score them 🔥/👌/🤷, pick the strongest. Track which scoring → actual open-rate over 12 issues; you'll calibrate fast.
- **Hook is 90% of remaining 20%**: if first 2 sentences don't hold, nobody finishes.
- **CTA matters more than length**: every issue should have ONE clear ask (reply / click / share / forward / buy).
- **Track Tweet teasers**: tweets driving newsletter signups are gold — find the pattern.

---

*Part of The X Creator OS — Notion Stack.*
