# Sponsorship CRM

> Notion template — track brand outreach from cold pitch through paid + delivered.
> **Import**: New page → ⋯ → Import → Markdown → select this file.

---

## Database 1: Brands

| Property | Type | Options / Formula |
|---|---|---|
| Brand | Title | (company name) |
| Industry | Multi-select | SaaS / Dev tools / Newsletter platform / VC / DTC / Education / AI / Crypto / Other |
| Stage | Select | 🌱 Researching / 📤 Cold pitched / 💬 Replied / 🤝 Negotiating / ✅ Signed / 💰 Paid / 📦 Delivered / ❌ Lost / 😴 No reply |
| Fit score | Select | 🎯 Perfect / 👍 Good / 🤷 Maybe / 🚫 Bad |
| Audience overlap | Select | 80%+ / 50-80% / 20-50% / <20% |
| Contact name | Text | (decision maker) |
| Contact email | Email | |
| Contact LinkedIn / X | URL | |
| First touch date | Date | |
| Last interaction | Date | |
| Next followup | Date | |
| Quote (if any) | Number | (their offer in USD) |
| My ask | Number | (your minimum acceptable rate) |
| Final price | Number | (signed amount) |
| Deliverables | Multi-select | Sponsored tweet thread / Newsletter ad / Newsletter sponsorship issue / YouTube integration / Logo placement / Discount code / Affiliate share |
| Deliverable count | Number | |
| Effective rate / deliverable | Formula | `prop("Final price") / prop("Deliverable count")` |
| CPM (per 1k impressions) | Formula | `prop("Final price") / prop("Total impressions delivered") * 1000` |
| Total impressions delivered | Number | (after delivery, manual) |
| Source | Select | Cold outreach / Inbound DM / Inbound email / Referral / Sponsorship marketplace |
| Source link | URL | (e.g. their original DM screenshot) |
| Notes | Text | |

---

## Database 2: Pitches Sent

| Property | Type | Options / Formula |
|---|---|---|
| Subject | Title | (email subject) |
| Brand | Relation → Brands | |
| Sent date | Date | |
| Pitch template used | Select | V1 short / V1 long / V2 case-study / V2 metrics-led / Custom |
| Body | Text | |
| Opened? | Checkbox | (if you have email tracking) |
| Replied? | Checkbox | |
| Reply date | Date | |
| Reply sentiment | Select | 🟢 positive / 🟡 lukewarm / 🔴 polite no / 🚫 hard no |
| Conversion to signed | Checkbox | |

---

## Views — Brands DB

### 1. 🎯 Active pipeline (working deals)
- Filter: Stage IN [💬 Replied, 🤝 Negotiating, ✅ Signed]
- Sort: Last interaction desc
- Layout: Board (group by Stage)
- Use: daily check what needs follow-up

### 2. 🌱 Research queue (not yet contacted)
- Filter: Stage IN [🌱 Researching]
- Sort: Fit score → Audience overlap
- Layout: Table
- Use: weekly outreach planning

### 3. 🔁 Followup needed (cold pitched, no reply >7 days)
- Filter: Stage = 📤 Cold pitched AND First touch date <= TODAY-7
- Sort: First touch date asc
- Layout: Table
- Use: weekly second-touch (40% of replies come from second pitch)

### 4. 💰 Paid + delivering
- Filter: Stage IN [💰 Paid, 📦 Delivered]
- Sort: First touch date desc
- Layout: Table with CPM column
- Use: see what your actual CPM trends are

### 5. ❌ Lost reasons
- Filter: Stage = ❌ Lost
- Group by: Industry
- Use: post-mortem; spot pattern in losses

### 6. 📊 By Industry
- Group by: Industry
- Sort: Final price desc
- Use: which industries pay best

---

## Views — Pitches DB

### 7. 🧪 Pitch template performance
- Group by: Pitch template used
- Show: count of Replied (Yes) / Conversion to signed (Yes)
- Use: A/B test what subject lines / structures convert

---

## Workflow

### Weekly outreach (90 min)
1. Open **🌱 Research queue**
2. Pick 3 brands with Fit score = 🎯 Perfect or 👍 Good
3. Move stage to 📤 Cold pitched, write pitch, log to Pitches Sent DB
4. Open **🔁 Followup needed** — send second-touch on any 7+ day cold pitches

### Daily check (5 min, weekday morning)
1. Open **🎯 Active pipeline**
2. Reply to any new responses
3. Update Stage / Last interaction / Next followup

### Per-deal close (10 min)
1. Set Stage = ✅ Signed
2. Fill Final price / Deliverables / Deliverable count
3. Calendar reminder: deliver by deadline

### Per-deal post-delivery (10 min)
1. Set Stage = 📦 Delivered
2. Fill Total impressions delivered (24-72h after sponsored content live)
3. CPM auto-computes
4. If client happy → ask for referral (track in Brands as new row, Source = Referral)

### Monthly (30 min)
1. Open **💰 Paid + delivering** — sum revenue
2. Open **🧪 Pitch template performance** — kill losing templates
3. Open **❌ Lost reasons** — pattern recognition

---

## Pre-loaded sample data

| Brand | Stage | Fit | Audience overlap | Contact | First touch | Final price |
|---|---|---|---|---|---|---|
| Beehiiv | 🤝 Negotiating | 🎯 Perfect | 80%+ | Brittany M. | 2026-04-15 | (TBD) |
| Notion | 📤 Cold pitched | 👍 Good | 50-80% | (no reply) | 2026-04-20 | — |
| Vercel | 🌱 Researching | 🎯 Perfect | 80%+ | (TBD) | — | — |

---

## Tips

- **Outreach math**: aim 10 cold pitches → 2 replies → 1 negotiation → 0.5 signed. So 20 pitches/month for 1 deal.
- **CPM benchmark**: indie creator sponsorship CPMs typically $20-$80. Below $20 you're underpricing; above $80 brand pushback.
- **Don't undersell deliverables**: 1 tweet thread + 1 newsletter mention = 2 deliverables, NOT 1. Price accordingly.
- **Track Source**: referrals close 5x faster than cold. Build a habit of asking happy clients.

---

## Bonus: pitch templates (in Pro Pack)

Pro Pack ($29) adds the **Sponsorship Pitch Deck template** — pre-written pitch templates V1/V2/V3 with placeholder fields for your metrics. Standard buyers can write their own; Pro buyers get templates done.

---

*Part of The X Creator OS — Notion Stack.*
