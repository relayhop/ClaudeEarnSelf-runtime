# Theme: 🌑 dark

## Visual identity
- **Vibe**: terminal aesthetic, dark page background, monospaced fonts, accent green/cyan
- **Page cover image**: (use AI image gen with prompt below)
- **Section emojis**: ⬛ ⬜ 🌙 ⭐ 🌟

## Color palette
-  1. #0A0A0A
-  2. #FFFFFF
-  3. #888888
-  4. #1A1A1A

## Typography
- **Headings & body**: JetBrains Mono; SF Mono

## Notion application steps

### Page-level (apply to top-level X Creator OS page)
1. Click cover image area → **Add cover** → **Upload** → use generated cover (see prompt below)
2. Click page icon (top of page) → **Emoji** → set: 🌑

### Sub-page level (each of the 5 templates)
1. Set page icon emoji from this theme set: ⬛ ⬜ 🌙 ⭐ 🌟
2. Apply matching color to title bar via Notion's page color (Notion has 9 color options — match closest to palette)

### Database styling
1. Each database → **⋯ menu** → **Customize page** → **Card preview** → use cover image variant
2. Tags / Select properties → use this palette's accent color

### Cover image gen prompt (use Midjourney / DALL-E / Imagen / Magnific)
```
dark aesthetic notion template cover, #0A0A0A #FFFFFF #888888 #1A1A1A color palette, JetBrains Mono typography style, 2400x600 wide banner, no text, abstract, terminal aesthetic, dark page background, monospaced fonts, accent green/cyan
```

## Theme example sections (copy-paste to listing screenshots)

- 📌 Project Hub → 🌑 Hub
- 📅 Calendar → 🌑 Schedule  
- 📊 Dashboard → 🌑 Numbers
- 📝 Notes → 🌑 Pages

---

*This theme is part of The X Creator OS Standard (.50) and above. Apply once, persists everywhere.*
