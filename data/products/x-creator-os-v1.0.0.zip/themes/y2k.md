# Theme: 💾 y2k

## Visual identity
- **Vibe**: cyber neon, bubble emojis, retro 2000s aesthetic
- **Page cover image**: (use AI image gen with prompt below)
- **Section emojis**: 💿 🦋 ⭐ 🌟 📼

## Color palette
-  1. #1A0033
-  2. #FF00FF
-  3. #00FFFF
-  4. #FFFF00

## Typography
- **Headings & body**: Press Start 2P; VT323

## Notion application steps

### Page-level (apply to top-level X Creator OS page)
1. Click cover image area → **Add cover** → **Upload** → use generated cover (see prompt below)
2. Click page icon (top of page) → **Emoji** → set: 💾

### Sub-page level (each of the 5 templates)
1. Set page icon emoji from this theme set: 💿 🦋 ⭐ 🌟 📼
2. Apply matching color to title bar via Notion's page color (Notion has 9 color options — match closest to palette)

### Database styling
1. Each database → **⋯ menu** → **Customize page** → **Card preview** → use cover image variant
2. Tags / Select properties → use this palette's accent color

### Cover image gen prompt (use Midjourney / DALL-E / Imagen / Magnific)
```
y2k aesthetic notion template cover, #1A0033 #FF00FF #00FFFF #FFFF00 color palette, Press Start 2P typography style, 2400x600 wide banner, no text, abstract, cyber neon, bubble emojis, retro 2000s aesthetic
```

## Theme example sections (copy-paste to listing screenshots)

- 📌 Project Hub → 💾 Hub
- 📅 Calendar → 💾 Schedule  
- 📊 Dashboard → 💾 Numbers
- 📝 Notes → 💾 Pages

---

*This theme is part of The X Creator OS Standard (.50) and above. Apply once, persists everywhere.*
