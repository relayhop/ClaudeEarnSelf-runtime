# Theme: ☁️ minimalist

## Visual identity
- **Vibe**: less is more, white space, narrow column, no decorative emoji except section headers
- **Page cover image**: (use AI image gen with prompt below)
- **Section emojis**: ⚪ ⚫ ◽ ◾ 📄

## Color palette
-  1. #FAFAFA
-  2. #232323
-  3. #6B6B6B
-  4. #E8E8E8

## Typography
- **Headings & body**: ABC Favorit; Inter

## Notion application steps

### Page-level (apply to top-level X Creator OS page)
1. Click cover image area → **Add cover** → **Upload** → use generated cover (see prompt below)
2. Click page icon (top of page) → **Emoji** → set: ☁️

### Sub-page level (each of the 5 templates)
1. Set page icon emoji from this theme set: ⚪ ⚫ ◽ ◾ 📄
2. Apply matching color to title bar via Notion's page color (Notion has 9 color options — match closest to palette)

### Database styling
1. Each database → **⋯ menu** → **Customize page** → **Card preview** → use cover image variant
2. Tags / Select properties → use this palette's accent color

### Cover image gen prompt (use Midjourney / DALL-E / Imagen / Magnific)
```
minimalist aesthetic notion template cover, #FAFAFA #232323 #6B6B6B #E8E8E8 color palette, ABC Favorit typography style, 2400x600 wide banner, no text, abstract, less is more, white space, narrow column, no decorative emoji except section headers
```

## Theme example sections (copy-paste to listing screenshots)

- 📌 Project Hub → ☁️ Hub
- 📅 Calendar → ☁️ Schedule  
- 📊 Dashboard → ☁️ Numbers
- 📝 Notes → ☁️ Pages

---

*This theme is part of The X Creator OS Standard (.50) and above. Apply once, persists everywhere.*
