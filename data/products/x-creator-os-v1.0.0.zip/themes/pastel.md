# Theme: 🌸 pastel

## Visual identity
- **Vibe**: soft cream + blush + sage + peach palette, serif headings
- **Page cover image**: (use AI image gen with prompt below)
- **Section emojis**: 🌷 💗 ✨ 🌸 🌼

## Color palette
-  1. #FFF5F7
-  2. #FFB3C6
-  3. #B5EAD7
-  4. #FFDAC1

## Typography
- **Headings & body**: Crimson Text; Playfair

## Notion application steps

### Page-level (apply to top-level X Creator OS page)
1. Click cover image area → **Add cover** → **Upload** → use generated cover (see prompt below)
2. Click page icon (top of page) → **Emoji** → set: 🌸

### Sub-page level (each of the 5 templates)
1. Set page icon emoji from this theme set: 🌷 💗 ✨ 🌸 🌼
2. Apply matching color to title bar via Notion's page color (Notion has 9 color options — match closest to palette)

### Database styling
1. Each database → **⋯ menu** → **Customize page** → **Card preview** → use cover image variant
2. Tags / Select properties → use this palette's accent color

### Cover image gen prompt (use Midjourney / DALL-E / Imagen / Magnific)
```
pastel aesthetic notion template cover, #FFF5F7 #FFB3C6 #B5EAD7 #FFDAC1 color palette, Crimson Text typography style, 2400x600 wide banner, no text, abstract, soft cream + blush + sage + peach palette, serif headings
```

## Theme example sections (copy-paste to listing screenshots)

- 📌 Project Hub → 🌸 Hub
- 📅 Calendar → 🌸 Schedule  
- 📊 Dashboard → 🌸 Numbers
- 📝 Notes → 🌸 Pages

---

*This theme is part of The X Creator OS Standard (.50) and above. Apply once, persists everywhere.*
